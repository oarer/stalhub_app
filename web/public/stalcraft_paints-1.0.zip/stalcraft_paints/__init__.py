bl_info = {
    "name": "Stalcraft paints",
    "author": "DeTTK",
    "version": (2, 0, 0),
    "blender": (4, 3, 0),
    "location": "Shader Editor > Add > Stalcraft; Shader Editor > Sidebar > Stalcraft",
    "description": "Game-accurate Stalcraft skin masks with Git-hosted paint libraries",
    "category": "Node",
}

import json
from pathlib import Path
import urllib.parse
import urllib.request

import bpy
from bpy.props import (
    BoolProperty,
    EnumProperty,
    FloatProperty,
    FloatVectorProperty,
    PointerProperty,
    StringProperty,
    CollectionProperty,
)
from bpy.types import (
    AddonPreferences,
    Operator,
    Panel,
    PropertyGroup,
    ShaderNodeCustomGroup,
)


ADDON_ID = __package__ or __name__
NODE_IDNAME = "SCShaderNodeStalcraftPaints"
TREE_TAG = "scpaint_generated_tree"
SCHEMA_ID = "stalcraft-paints-library/v2"

DMAP_COLOR = "Diffuse / Base Color"
DMAP_ALPHA = "Diffuse Alpha / Paint Mask"
NMAP_COLOR = "Normal Map"
SMAP_COLOR = "Specular Map"
EMAP_COLOR = "Emission Map"
PRIMARY_PAINT_COLOR = "Primary Paint Color"
PRIMARY_COLOR = "Primary Paint Diffuse Texture"
PRIMARY_ALPHA = "Primary Paint Alpha"
PRIMARY_EMISSION = "Primary Emission"
SECONDARY_PAINT_COLOR = "Secondary Paint Color"
SECONDARY_ZONE_ENABLED = "Enable Secondary Paint Zone"
SECONDARY_COLOR = "Secondary Paint Diffuse Texture"
SECONDARY_ALPHA = "Secondary Paint Alpha"
SECONDARY_EMISSION = "Secondary Emission"

AUTO_COLOR_LABEL = "Auto Select Paint Color"

INPUT_NAMES = (
    DMAP_COLOR,
    DMAP_ALPHA,
    NMAP_COLOR,
    SMAP_COLOR,
    EMAP_COLOR,
    PRIMARY_COLOR,
    PRIMARY_ALPHA,
    PRIMARY_EMISSION,
    PRIMARY_PAINT_COLOR,
    SECONDARY_COLOR,
    SECONDARY_ALPHA,
    SECONDARY_EMISSION,
    SECONDARY_ZONE_ENABLED,
    SECONDARY_PAINT_COLOR,
)

INTERFACE_VERSION = 10
GRAPH_VERSION = 5

MODE_ITEMS = (
    (
        "dmap_alpha_as_dual_skin_mask",
        "Diffuse / Base Color Alpha - Dual Mask",
        "Diffuse alpha: values above 0.512 are Primary, below 0.488 are Secondary",
    ),
    (
        "dmap_alpha_as_skin_mask",
        "Diffuse / Base Color Alpha - Mask",
        "Diffuse alpha is the paint mask",
    ),
    (
        "nmap_blue_as_dual_skin_mask",
        "Normal Map Blue - Dual Mask",
        "Normal Map blue: values above 0.512 are Primary, below 0.488 are Secondary",
    ),
    (
        "nmap_blue_as_skin_mask",
        "Normal Map Blue - Mask",
        "Normal Map blue is the paint mask",
    ),
)

CATEGORY_ITEMS = (
    ("WEAPON", "Weapon", "Weapon paints"),
    ("ARMOR", "Armor", "Armor paints"),
)

def _is_dual(mode: str) -> bool:
    return mode.endswith("dual_skin_mask")


def _active_scpaint_node(context):
    space = getattr(context, "space_data", None)
    tree = getattr(space, "edit_tree", None)
    node = getattr(tree, "nodes", None)
    node = node.active if node else None
    return node if isinstance(node, SCShaderNodeStalcraftPaints) else None


def _new_node(nodes, node_type, name, x, y):
    node = nodes.new(node_type)
    node.name = name
    node.label = name
    node.location = (x, y)
    return node


def _math(nodes, operation, name, x, y, a=None, b=None, clamp=False):
    node = _new_node(nodes, "ShaderNodeMath", name, x, y)
    node.operation = operation
    node.use_clamp = clamp
    if a is not None:
        node.inputs[0].default_value = a
    if b is not None:
        node.inputs[1].default_value = b
    return node


def _link(tree, output, input_socket):
    tree.links.new(output, input_socket)


def _node_property_update(self, _context):
    if getattr(self, "node_tree", None) is not None:
        self.rebuild_tree()


def _texture_scale_update(self, _context):
    if getattr(self, "node_tree", None) is not None:
        self.sync_linked_paint_texture_scale()
        self.rebuild_tree()


class SCShaderNodeStalcraftPaints(ShaderNodeCustomGroup):
    bl_idname = NODE_IDNAME
    bl_label = "Stalcraft paints"
    bl_description = "Stalcraft material maps and primary/dual paint zones"
    bl_icon = "NODE_MATERIAL"

    mode: EnumProperty(name="Mask Source", items=MODE_ITEMS, update=_node_property_update)
    category: EnumProperty(name="Paint Type", items=CATEGORY_ITEMS, default="WEAPON")
    invert_mask: BoolProperty(name="Invert Mask", default=False, update=_node_property_update)
    auto_select_paint_color: BoolProperty(
        name=AUTO_COLOR_LABEL,
        description=(
            "Automatically use a connected or preset paint diffuse texture as "
            "the paint color; disable to use the Paint Color sockets"
        ),
        default=True,
        update=_node_property_update,
    )
    search_query: StringProperty(name="Search", default="")
    manual_mode: BoolProperty(name="Manual Mode", default=False)
    use_dual_specular_override: BoolProperty(
        name="Override Dual Specular", default=False, update=_node_property_update
    )
    show_base_section: BoolProperty(name="Base Material Maps", default=True)
    show_primary_section: BoolProperty(name="Primary Paint Zone", default=True)
    show_secondary_section: BoolProperty(name="Secondary Paint Zone", default=True)
    dual_specular_color: FloatVectorProperty(
        name="Dual Specular",
        subtype="COLOR",
        size=4,
        min=0.0,
        max=1.0,
        default=(0.07, 0.07, 0.07, 1.0),
        update=_node_property_update,
    )
    texture_scale: FloatProperty(
        name="Texture Scale",
        description="Stalcraft sm_texScale for preset and directly linked paint Image Texture nodes",
        default=1.0,
        min=0.001,
        soft_max=16.0,
        update=_texture_scale_update,
    )

    @classmethod
    def poll(cls, node_tree):
        return node_tree is not None and node_tree.bl_idname == "ShaderNodeTree"

    def init(self, _context):
        self.width = 500
        self.use_custom_color = True
        self.color = (0.055, 0.30, 0.018)
        self.node_tree = bpy.data.node_groups.new(f"Stalcraft paints | {self.name}", "ShaderNodeTree")
        self.node_tree[TREE_TAG] = True
        self._subscribe_msgbus()
        self.rebuild_tree()

    def copy(self, source_node):
        if source_node.node_tree:
            self.node_tree = source_node.node_tree.copy()
            self.node_tree[TREE_TAG] = True
        self._subscribe_msgbus()

    def free(self):
        self._unsubscribe_msgbus()
        tree = self.node_tree
        self.node_tree = None
        if tree and tree.get(TREE_TAG) and tree.users == 0:
            bpy.data.node_groups.remove(tree)

    def update(self):
        # Link edits can arrive before Blender dispatches msgbus notifications;
        # synchronize numeric selectors only, never rebuild the live topology.
        if not self.get("_scpaint_rebuilding", False):
            self.sync_external_links()

    def _subscribe_msgbus(self):
        # Link changes are observed without polling or mutating live topology.
        try:
            bpy.msgbus.clear_by_owner(self)
            bpy.msgbus.subscribe_rna(
                key=(self.id_data, "links"),
                owner=self,
                args=(self,),
                notify=_msgbus_sync_node,
            )
        except (AttributeError, TypeError, RuntimeError):
            pass

    def _unsubscribe_msgbus(self):
        try:
            bpy.msgbus.clear_by_owner(self)
        except (AttributeError, RuntimeError):
            pass

    def external_link_mask(self):
        mask = 0
        for index, name in enumerate(INPUT_NAMES):
            socket = self.inputs.get(name)
            if socket is not None and socket.is_linked:
                mask |= 1 << index
        return mask

    def _linked_paint_image_nodes(self):
        image_nodes = {}
        for socket_name in (
            PRIMARY_COLOR,
            PRIMARY_ALPHA,
            PRIMARY_EMISSION,
            SECONDARY_COLOR,
            SECONDARY_ALPHA,
            SECONDARY_EMISSION,
        ):
            socket = self.inputs.get(socket_name)
            if socket is None:
                continue
            for link in socket.links:
                node = link.from_node
                # Follow reroutes without taking ownership of arbitrary user node graphs.
                while node is not None and node.type == "REROUTE":
                    reroute_input = node.inputs[0]
                    node = reroute_input.links[0].from_node if reroute_input.is_linked else None
                if node is not None and node.type == "TEX_IMAGE":
                    image_nodes[node.as_pointer()] = node
        return image_nodes.values()

    def sync_linked_paint_texture_scale(self):
        target = (self.texture_scale,) * 3
        changed = False
        for image_node in self._linked_paint_image_nodes():
            if any(
                abs(actual - expected) > 1e-6
                for actual, expected in zip(image_node.texture_mapping.scale, target)
            ):
                image_node.texture_mapping.scale = target
                changed = True
        return changed

    def sync_external_links(self):
        tree = self.node_tree
        if tree is None:
            return False
        changed = False
        for zone, socket_name in (
            ("Primary", PRIMARY_COLOR),
            ("Secondary", SECONDARY_COLOR),
        ):
            selector = tree.nodes.get(f"Use {zone} Paint Texture")
            socket = self.inputs.get(socket_name)
            if selector is None or socket is None:
                continue
            value = (
                1.0
                if self.auto_select_paint_color and socket.is_linked
                else 0.0
            )
            if selector.outputs[0].default_value != value:
                selector.outputs[0].default_value = value
                changed = True
        for zone, socket_name in (("Primary", PRIMARY_ALPHA), ("Secondary", SECONDARY_ALPHA)):
            selector = tree.nodes.get(f"Use {zone} Paint Alpha")
            socket = self.inputs.get(socket_name)
            if selector is None or socket is None:
                continue
            value = 1.0 if socket.is_linked else 0.0
            if selector.outputs[0].default_value != value:
                selector.outputs[0].default_value = value
                changed = True
        if self.sync_linked_paint_texture_scale():
            changed = True
        self["_scpaint_link_mask"] = self.external_link_mask()
        return changed

    def _ensure_interface(self, primary_color, dual_color):
        expected_inputs = INPUT_NAMES
        expected_outputs = (
            "Base Color",
            "Specular",
            "Alpha",
            "Normal",
            "Emission",
            "Primary Mask",
            "Dual Mask",
        )
        panel_names = tuple(
            item.name
            for item in self.node_tree.interface.items_tree
            if item.item_type == "PANEL"
        )
        expected_parents = {
            name: "BASE TEXTURE INPUTS"
            for name in (DMAP_COLOR, DMAP_ALPHA, NMAP_COLOR, SMAP_COLOR, EMAP_COLOR)
        }
        expected_parents.update(
            {
                PRIMARY_COLOR: "PRIMARY PAINT ZONE",
                PRIMARY_ALPHA: "PRIMARY PAINT ZONE",
                PRIMARY_EMISSION: "PRIMARY PAINT ZONE",
                PRIMARY_PAINT_COLOR: "PRIMARY PAINT ZONE",
                SECONDARY_COLOR: "SECONDARY PAINT ZONE",
                SECONDARY_ALPHA: "SECONDARY PAINT ZONE",
                SECONDARY_EMISSION: "SECONDARY PAINT ZONE",
                SECONDARY_ZONE_ENABLED: "SECONDARY PAINT ZONE",
                SECONDARY_PAINT_COLOR: "SECONDARY PAINT ZONE",
            }
        )
        interface_inputs = {
            item.name: item
            for item in self.node_tree.interface.items_tree
            if item.item_type == "SOCKET" and item.in_out == "INPUT"
        }
        if (
            tuple(socket.name for socket in self.inputs) == expected_inputs
            and tuple(socket.name for socket in self.outputs) == expected_outputs
            and panel_names
            == ("BASE TEXTURE INPUTS", "PRIMARY PAINT ZONE", "SECONDARY PAINT ZONE")
            and all(
                interface_inputs.get(name) is not None
                and interface_inputs[name].parent is not None
                and interface_inputs[name].parent.name == parent
                for name, parent in expected_parents.items()
            )
        ):
            return
        interface = self.node_tree.interface

        # Reuse the current v2 items when only their panel placement is stale.
        # Moving interface items preserves external links; clearing is reserved
        # for genuinely incompatible interfaces, as required by v2.
        panels = {
            item.name: item
            for item in interface.items_tree
            if item.item_type == "PANEL"
        }
        if (
            set(interface_inputs) >= set(expected_inputs)
            and len(panels) >= 3
        ):
            base_panel = panels.get("BASE TEXTURE INPUTS") or panels.get("TEXTURE INPUTS")
            primary_panel = panels.get("PRIMARY PAINT ZONE")
            secondary_panel = panels.get("SECONDARY PAINT ZONE")
            if base_panel and primary_panel and secondary_panel:
                base_panel.name = "BASE TEXTURE INPUTS"
                for position, name in enumerate(
                    (DMAP_COLOR, DMAP_ALPHA, NMAP_COLOR, SMAP_COLOR, EMAP_COLOR)
                ):
                    interface.move_to_parent(interface_inputs[name], base_panel, position)
                for position, name in enumerate(
                    (PRIMARY_COLOR, PRIMARY_ALPHA, PRIMARY_EMISSION, PRIMARY_PAINT_COLOR)
                ):
                    interface.move_to_parent(interface_inputs[name], primary_panel, position)
                for position, name in enumerate(
                    (
                        SECONDARY_COLOR,
                        SECONDARY_ALPHA,
                        SECONDARY_EMISSION,
                        SECONDARY_ZONE_ENABLED,
                        SECONDARY_PAINT_COLOR,
                    )
                ):
                    interface.move_to_parent(interface_inputs[name], secondary_panel, position)
                return

        interface.clear()
        texture_panel = interface.new_panel(
            name="BASE TEXTURE INPUTS",
            description="External base material texture inputs",
            default_closed=False,
        )
        primary_panel = interface.new_panel(
            name="PRIMARY PAINT ZONE",
            description="Real linkable inputs for the high-value paint zone",
            default_closed=False,
        )
        secondary_panel = interface.new_panel(
            name="SECONDARY PAINT ZONE",
            description="Real linkable inputs for the low-value paint zone in dual modes",
            default_closed=False,
        )
        input_specs = (
            (DMAP_COLOR, "NodeSocketColor", (0.0, 0.0, 0.0, 1.0), "Diffuse/Base Color from Image Texture Color", texture_panel),
            (DMAP_ALPHA, "NodeSocketFloat", 1.0, "Diffuse alpha or paint mask from Image Texture Alpha", texture_panel),
            (NMAP_COLOR, "NodeSocketColor", (0.5, 0.5, 1.0, 1.0), "Encoded Normal Map RGB from Image Texture Color", texture_panel),
            (SMAP_COLOR, "NodeSocketColor", (0.0, 0.0, 0.0, 1.0), "Specular Map RGB from Image Texture Color", texture_panel),
            (EMAP_COLOR, "NodeSocketColor", (0.0, 0.0, 0.0, 1.0), "Emission Map RGB from Image Texture Color", texture_panel),
            (PRIMARY_COLOR, "NodeSocketColor", (0.0, 0.0, 0.0, 1.0), "Primary paint texture Color; use Non-Color data", primary_panel),
            (PRIMARY_ALPHA, "NodeSocketFloat", 1.0, "Primary diffuse opacity from Image Texture Alpha", primary_panel),
            (PRIMARY_EMISSION, "NodeSocketColor", (0.0, 0.0, 0.0, 1.0), "Primary emission from Image Texture Color", primary_panel),
            (SECONDARY_COLOR, "NodeSocketColor", (0.0, 0.0, 0.0, 1.0), "Secondary paint texture Color; use Non-Color data", secondary_panel),
            (SECONDARY_ALPHA, "NodeSocketFloat", 1.0, "Secondary diffuse opacity from Image Texture Alpha", secondary_panel),
            (SECONDARY_EMISSION, "NodeSocketColor", (0.0, 0.0, 0.0, 1.0), "Secondary emission from Image Texture Color", secondary_panel),
            (PRIMARY_PAINT_COLOR, "NodeSocketColor", primary_color, "Primary flat paint color", primary_panel),
            (SECONDARY_ZONE_ENABLED, "NodeSocketBool", True, "Apply the game dual-mask Secondary paint zone", secondary_panel),
            (SECONDARY_PAINT_COLOR, "NodeSocketColor", dual_color, "Secondary flat paint color", secondary_panel),
        )
        for name, socket_type, default, description, parent in input_specs:
            socket = interface.new_socket(
                name=name,
                in_out="INPUT",
                socket_type=socket_type,
                parent=parent,
            )
            socket.default_value = default
            socket.hide_value = name not in {
                PRIMARY_PAINT_COLOR,
                SECONDARY_ZONE_ENABLED,
                SECONDARY_PAINT_COLOR,
            }
            socket.description = description

        for name, socket_type in (
            ("Base Color", "NodeSocketColor"),
            ("Specular", "NodeSocketColor"),
            ("Alpha", "NodeSocketFloat"),
            ("Normal", "NodeSocketColor"),
            ("Emission", "NodeSocketColor"),
            ("Primary Mask", "NodeSocketFloat"),
            ("Dual Mask", "NodeSocketFloat"),
        ):
            socket = interface.new_socket(name=name, in_out="OUTPUT", socket_type=socket_type)
            if socket_type == "NodeSocketFloat":
                socket.min_value = 0.0
                socket.max_value = 1.0

        # Interface v10 intentionally does not migrate old links.

    def _gray_color(self, nodes, tree, color_output, prefix, x, y):
        split = _new_node(nodes, "ShaderNodeSeparateColor", f"{prefix} RGB", x, y)
        split.mode = "RGB"
        _link(tree, color_output, split.inputs["Color"])
        weighted = []
        for index, (channel, weight) in enumerate((("Red", 0.299), ("Green", 0.587), ("Blue", 0.114))):
            part = _math(nodes, "MULTIPLY", f"{prefix} {channel} weight", x + 210, y - index * 70, b=weight)
            _link(tree, split.outputs[channel], part.inputs[0])
            weighted.append(part)
        add_rg = _math(nodes, "ADD", f"{prefix} RG sum", x + 420, y - 35)
        gray = _math(nodes, "ADD", f"{prefix} Gray", x + 610, y - 70)
        _link(tree, weighted[0].outputs[0], add_rg.inputs[0])
        _link(tree, weighted[1].outputs[0], add_rg.inputs[1])
        _link(tree, add_rg.outputs[0], gray.inputs[0])
        _link(tree, weighted[2].outputs[0], gray.inputs[1])
        combine = _new_node(nodes, "ShaderNodeCombineColor", f"{prefix} Gray RGB", x + 800, y - 70)
        combine.mode = "RGB"
        for channel in ("Red", "Green", "Blue"):
            _link(tree, gray.outputs[0], combine.inputs[channel])
        return combine.outputs["Color"]

    def rebuild_tree(self):
        tree = self.node_tree
        if tree is None:
            return

        self["_scpaint_rebuilding"] = True
        self.use_custom_color = True
        self.color = (0.055, 0.30, 0.018)
        if self.width < 500:
            self.width = 500

        primary_color = tuple(
            self.inputs[PRIMARY_PAINT_COLOR].default_value
            if self.inputs.get(PRIMARY_PAINT_COLOR)
            else (0.8, 0.05, 0.03, 1.0)
        )
        dual_color = tuple(
            self.inputs[SECONDARY_PAINT_COLOR].default_value
            if self.inputs.get(SECONDARY_PAINT_COLOR)
            else (0.03, 0.08, 0.12, 1.0)
        )
        secondary_zone_enabled = bool(
            self.inputs[SECONDARY_ZONE_ENABLED].default_value
            if self.inputs.get(SECONDARY_ZONE_ENABLED)
            else True
        )
        self._ensure_interface(primary_color, dual_color)
        source_tree = self.node_tree
        replacement = source_tree.copy()
        replacement.name = f"{source_tree.name} | rebuild"
        replacement[TREE_TAG] = True
        self.node_tree = replacement
        tree = replacement
        self.inputs[PRIMARY_PAINT_COLOR].default_value = primary_color
        self.inputs[SECONDARY_PAINT_COLOR].default_value = dual_color
        self.inputs[SECONDARY_ZONE_ENABLED].default_value = secondary_zone_enabled
        for socket in self.inputs:
            socket.hide = False

        nodes = tree.nodes
        nodes.clear()
        group_in = _new_node(nodes, "NodeGroupInput", "Material Inputs", -1540, 100)
        group_out = _new_node(nodes, "NodeGroupOutput", "Material Maps", 1530, 330)
        group_out.is_active_output = True
        # All material maps are supplied by the external node graph.
        dmap_color = group_in.outputs[DMAP_COLOR]
        dmap_alpha = group_in.outputs[DMAP_ALPHA]
        normal_color = group_in.outputs[NMAP_COLOR]
        specular_color = group_in.outputs[SMAP_COLOR]
        emission_color = group_in.outputs[EMAP_COLOR]

        mask_source = dmap_alpha
        if self.mode.startswith("nmap_blue"):
            split_normal = _new_node(nodes, "ShaderNodeSeparateColor", "Normal Mask Channels", -1050, 650)
            split_normal.mode = "RGB"
            _link(tree, normal_color, split_normal.inputs["Color"])
            mask_source = split_normal.outputs["Blue"]
        if self.invert_mask:
            invert = _math(nodes, "SUBTRACT", "Invert Mask", -820, 610, a=1.0)
            _link(tree, mask_source, invert.inputs[1])
            mask_source = invert.outputs[0]

        if _is_dual(self.mode):
            primary_max = _math(nodes, "MAXIMUM", "Primary max(.512)", -590, 610, b=0.512)
            primary_sub = _math(nodes, "SUBTRACT", "Primary remap", -390, 610, b=0.512)
            primary = _math(nodes, "MULTIPLY", "Primary Mask", -190, 610, b=2.049, clamp=True)
            _link(tree, mask_source, primary_max.inputs[0])
            _link(tree, primary_max.outputs[0], primary_sub.inputs[0])
            _link(tree, primary_sub.outputs[0], primary.inputs[0])
            dual_min = _math(nodes, "MINIMUM", "Dual min(.488)", -590, 450, b=0.488)
            dual_sub = _math(nodes, "SUBTRACT", "Dual remap", -390, 450, a=0.488)
            dual = _math(nodes, "MULTIPLY", "Dual Mask", -190, 450, b=2.049, clamp=True)
            _link(tree, mask_source, dual_min.inputs[0])
            _link(tree, dual_min.outputs[0], dual_sub.inputs[1])
            _link(tree, dual_sub.outputs[0], dual.inputs[0])
        else:
            primary = _math(nodes, "MULTIPLY", "Primary Mask", -190, 610, b=1.0, clamp=True)
            _link(tree, mask_source, primary.inputs[0])
            dual = _math(nodes, "MULTIPLY", "Dual Mask", -190, 450, a=0.0, b=0.0, clamp=True)

        secondary_active = _math(
            nodes, "MULTIPLY", "Secondary Paint Zone Enabled", 10, 420, clamp=True
        )
        _link(tree, dual.outputs[0], secondary_active.inputs[0])
        _link(
            tree,
            group_in.outputs[SECONDARY_ZONE_ENABLED],
            secondary_active.inputs[1],
        )
        mask_sum = _math(nodes, "ADD", "Mask Sum", 10, 540, clamp=True)
        _link(tree, primary.outputs[0], mask_sum.inputs[0])
        _link(tree, secondary_active.outputs[0], mask_sum.inputs[1])
        smooth = _new_node(nodes, "ShaderNodeMapRange", "Desaturation smoothstep", 210, 560)
        smooth.data_type = "FLOAT"
        smooth.interpolation_type = "SMOOTHSTEP"
        smooth.clamp = True
        smooth.inputs["From Min"].default_value = 0.25
        smooth.inputs["From Max"].default_value = 0.6
        _link(tree, mask_sum.outputs[0], smooth.inputs["Value"])

        base_gray = self._gray_color(nodes, tree, dmap_color, "Diffuse", -760, 70)
        desaturate = _new_node(nodes, "ShaderNodeMixRGB", "Diffuse Desaturation", 300, 90)
        desaturate.blend_type = "MIX"
        _link(tree, dmap_color, desaturate.inputs[1])
        _link(tree, base_gray, desaturate.inputs[2])
        primary_source, primary_alpha = self._paint_source(nodes, tree, group_in, 1, -280)
        desat_factor = _math(nodes, "MULTIPLY", "Desaturation x Diffuse Alpha", 300, -90)
        _link(tree, smooth.outputs["Result"], desat_factor.inputs[0])
        _link(tree, primary_alpha, desat_factor.inputs[1])
        _link(tree, desat_factor.outputs[0], desaturate.inputs[0])
        primary_factor = _math(nodes, "MULTIPLY", "Primary x Diffuse Alpha", 500, -130)
        _link(tree, primary.outputs[0], primary_factor.inputs[0])
        _link(tree, primary_alpha, primary_factor.inputs[1])
        primary_mix = _new_node(nodes, "ShaderNodeMixRGB", "Apply Primary Diffuse", 610, 100)
        _link(tree, primary_factor.outputs[0], primary_mix.inputs[0])
        _link(tree, desaturate.outputs[0], primary_mix.inputs[1])
        _link(tree, primary_source, primary_mix.inputs[2])
        final_color = primary_mix.outputs[0]
        if _is_dual(self.mode):
            dual_source, dual_alpha = self._paint_source(nodes, tree, group_in, 2, -520)
            dual_factor = _math(nodes, "MULTIPLY", "Dual x Diffuse Alpha", 650, -350)
            _link(tree, secondary_active.outputs[0], dual_factor.inputs[0])
            _link(tree, dual_alpha, dual_factor.inputs[1])
            dual_mix = _new_node(nodes, "ShaderNodeMixRGB", "Apply Dual Diffuse", 900, 100)
            _link(tree, dual_factor.outputs[0], dual_mix.inputs[0])
            _link(tree, primary_mix.outputs[0], dual_mix.inputs[1])
            _link(tree, dual_source, dual_mix.inputs[2])
            final_color = dual_mix.outputs[0]

        final_specular = specular_color
        if _is_dual(self.mode) and self.use_dual_specular_override:
            dual_spec_rgb = _new_node(nodes, "ShaderNodeRGB", "Secondary Specular Color", 760, -690)
            dual_spec_rgb.outputs[0].default_value = self.dual_specular_color
            spec_dual = _new_node(nodes, "ShaderNodeMixRGB", "Apply Secondary Specular", 1010, -620)
            _link(tree, secondary_active.outputs[0], spec_dual.inputs[0])
            _link(tree, specular_color, spec_dual.inputs[1])
            _link(tree, dual_spec_rgb.outputs[0], spec_dual.inputs[2])
            final_specular = spec_dual.outputs[0]

        final_emission = emission_color
        primary_emission = group_in.outputs[PRIMARY_EMISSION]
        primary_emission_present = _new_node(
            nodes, "ShaderNodeValue", "Use Primary Emission", 1090, -950
        ).outputs[0]
        primary_emission_present.default_value = 1.0 if self.inputs[PRIMARY_EMISSION].is_linked else 0.0
        primary_emission_factor = _math(
            nodes, "MULTIPLY", "Primary Emission Enabled", 980, -900
        )
        _link(tree, primary.outputs[0], primary_emission_factor.inputs[0])
        _link(tree, primary_emission_present, primary_emission_factor.inputs[1])
        emission_mix = _new_node(nodes, "ShaderNodeMixRGB", "Apply Primary Emission", 1180, -820)
        _link(tree, primary_emission_factor.outputs[0], emission_mix.inputs[0])
        _link(tree, emission_color, emission_mix.inputs[1])
        _link(tree, primary_emission, emission_mix.inputs[2])
        final_emission = emission_mix.outputs[0]
        if _is_dual(self.mode):
            secondary_emission = group_in.outputs[SECONDARY_EMISSION]
            secondary_emission_present = _new_node(
                nodes, "ShaderNodeValue", "Use Secondary Emission", 1090, -1150
            ).outputs[0]
            secondary_emission_present.default_value = 1.0 if self.inputs[SECONDARY_EMISSION].is_linked else 0.0
            secondary_emission_factor = _math(
                nodes, "MULTIPLY", "Secondary Emission Enabled", 1180, -1080
            )
            _link(tree, secondary_active.outputs[0], secondary_emission_factor.inputs[0])
            _link(tree, secondary_emission_present, secondary_emission_factor.inputs[1])
            emission_dual = _new_node(nodes, "ShaderNodeMixRGB", "Apply Secondary Emission", 1380, -820)
            _link(tree, secondary_emission_factor.outputs[0], emission_dual.inputs[0])
            _link(tree, final_emission, emission_dual.inputs[1])
            _link(tree, secondary_emission, emission_dual.inputs[2])
            final_emission = emission_dual.outputs[0]

        _link(tree, final_color, group_out.inputs["Base Color"])
        _link(tree, final_specular, group_out.inputs["Specular"])
        _link(tree, dmap_alpha, group_out.inputs["Alpha"])
        _link(tree, normal_color, group_out.inputs["Normal"])
        _link(tree, final_emission, group_out.inputs["Emission"])
        _link(tree, primary.outputs[0], group_out.inputs["Primary Mask"])
        _link(tree, dual.outputs[0], group_out.inputs["Dual Mask"])
        self["_scpaint_interface_version"] = INTERFACE_VERSION
        tree["_scpaint_graph_version"] = GRAPH_VERSION
        # Re-apply the scale after the detached graph swap so every directly
        # linked paint Image Texture keeps the selected tiling value.
        self.sync_linked_paint_texture_scale()
        self["_scpaint_link_mask"] = self.external_link_mask()
        self["_scpaint_rebuilding"] = False
        if source_tree.get(TREE_TAG) and source_tree.users == 0:
            bpy.data.node_groups.remove(source_tree)

    def _paint_source(self, nodes, tree, group_in, index, y):
        zone = "Primary" if index == 1 else "Secondary"
        paint_color_socket = PRIMARY_PAINT_COLOR if index == 1 else SECONDARY_PAINT_COLOR
        texture_socket = PRIMARY_COLOR if index == 1 else SECONDARY_COLOR
        alpha_socket = PRIMARY_ALPHA if index == 1 else SECONDARY_ALPHA
        gamma = _new_node(nodes, "ShaderNodeGamma", f"{zone} Diffuse toLinear", 20, y + 100)
        gamma.inputs["Gamma"].default_value = 2.2
        _link(tree, group_in.outputs[texture_socket], gamma.inputs["Color"])

        # A linked paint texture is the game-like automatic color source. The
        # selector is a Value node so link changes can update it without
        # rebuilding or clearing the live shader group.
        paint_texture_selector = _new_node(
            nodes, "ShaderNodeValue", f"Use {zone} Paint Texture", 20, y + 10
        )
        paint_texture_selector.outputs[0].default_value = (
            1.0
            if self.auto_select_paint_color
            and self.inputs[texture_socket].is_linked
            else 0.0
        )
        color = _new_node(nodes, "ShaderNodeMixRGB", f"{zone} Paint Source", 230, y + 80)
        _link(tree, paint_texture_selector.outputs[0], color.inputs[0])
        _link(tree, group_in.outputs[paint_color_socket], color.inputs[1])
        _link(tree, gamma.outputs["Color"], color.inputs[2])

        texture_alpha = group_in.outputs[alpha_socket]
        paint_alpha_selector = _new_node(
            nodes, "ShaderNodeValue", f"Use {zone} Paint Alpha", 20, y - 110
        )
        paint_alpha_selector.outputs[0].default_value = 1.0 if self.inputs[alpha_socket].is_linked else 0.0
        alpha_weight = _math(nodes, "SUBTRACT", f"{zone} Flat Color Alpha", 410, y - 100, a=1.0)
        alpha_texture = _math(nodes, "MULTIPLY", f"{zone} Texture Alpha", 600, y - 130)
        alpha = _math(nodes, "ADD", f"{zone} Paint Alpha", 790, y - 100)
        _link(tree, paint_alpha_selector.outputs[0], alpha_weight.inputs[1])
        _link(tree, texture_alpha, alpha_texture.inputs[0])
        _link(tree, paint_alpha_selector.outputs[0], alpha_texture.inputs[1])
        _link(tree, alpha_weight.outputs[0], alpha.inputs[0])
        _link(tree, alpha_texture.outputs[0], alpha.inputs[1])
        return color.outputs[0], alpha.outputs[0]

    def draw_buttons(self, _context, layout):
        # Reuse the same preview icon in the node body; the Add menu uses it
        # through icon_value as well, so Blender never falls back to a built-in icon name.
        layout.label(text="Stalcraft Paints", icon_value=get_icon_value())
        layout.prop(self, "mode", text="")
        layout.prop(self, "category", expand=True)

        split = layout.split(factor=0.46, align=True)
        split.row(align=True).prop(self, "invert_mask")
        scale_row = split.row(align=True)
        scale_row.label(text="Texture Scale")
        scale_row.prop(self, "texture_scale", text="")
        layout.prop(self, "auto_select_paint_color", text=AUTO_COLOR_LABEL)

        if _is_dual(self.mode):
            row = layout.row(align=True)
            row.prop(self, "use_dual_specular_override", text="Override Secondary Specular", toggle=True)
            if self.use_dual_specular_override:
                row.prop(self, "dual_specular_color", text="")

        layout.prop(self, "manual_mode", text="Ручной режим")
        if not self.manual_mode:
            layout.prop(self, "search_query", text="Поиск")
            layout.operator("scpaint.search_presets", text="Найти пресет")
        layout.operator("scpaint.create_or_update", text="Rebuild Internal Tree", icon="FILE_REFRESH")


def _validate_library(data):
    if not isinstance(data, dict):
        raise ValueError("Library root must be a JSON object")
    if data.get("schema") != SCHEMA_ID:
        raise ValueError(f"Unsupported schema: expected {SCHEMA_ID!r}")
    if not isinstance(data.get("presets"), list):
        raise ValueError("'presets' must be an array")
    seen = set()
    valid_modes = {item[0] for item in MODE_ITEMS}
    for entry in data["presets"]:
        if (
            not isinstance(entry, dict)
            or not isinstance(entry.get("id"), str)
            or not entry["id"]
            or not isinstance(entry.get("name"), str)
            or not entry["name"]
        ):
            raise ValueError("Every preset needs string id and name")
        if entry["id"] in seen:
            raise ValueError(f"Duplicate preset id: {entry['id']}")
        seen.add(entry["id"])
        if entry.get("type", "").lower() not in {"weapon", "armor"}:
            raise ValueError(f"Preset {entry['id']} must have weapon or armor type")
        if entry.get("mode") not in valid_modes:
            raise ValueError(f"Preset {entry['id']} has an unsupported mask mode")
        if not isinstance(entry.get("invert_mask", False), bool):
            raise ValueError(f"Preset {entry['id']} invert_mask must be boolean")
        if not isinstance(entry.get("texture_scale", 1.0), (int, float)) or entry.get("texture_scale", 1.0) <= 0:
            raise ValueError(f"Preset {entry['id']} texture_scale must be positive")
    return data


def _github_raw_url(url):
    parsed = urllib.parse.urlparse(url)
    if parsed.netloc.lower() == "github.com" and "/blob/" in parsed.path:
        path = parsed.path.replace("/blob/", "/", 1)
        return urllib.parse.urlunparse(
            ("https", "raw.githubusercontent.com", path, "", "", "")
        )
    return url


def _download(url, destination=None, max_bytes=64 * 1024 * 1024):
    url = _github_raw_url(url)
    request = urllib.request.Request(url, headers={"User-Agent": "Blender-Stalcraft-Paints/1.0"})
    with urllib.request.urlopen(request, timeout=20) as response:
        length = response.headers.get("Content-Length")
        if length and int(length) > max_bytes:
            raise ValueError(f"Remote file is larger than {max_bytes // (1024 * 1024)} MB")
        chunks = []
        size = 0
        while True:
            chunk = response.read(1024 * 1024)
            if not chunk:
                break
            size += len(chunk)
            if size > max_bytes:
                raise ValueError(f"Remote file is larger than {max_bytes // (1024 * 1024)} MB")
            chunks.append(chunk)
    data = b"".join(chunks)
    if destination:
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
    return data


def _load_library(context, source):
    source = source.strip()
    if source.startswith(("http://", "https://")):
        source = _github_raw_url(source)
        raw = _download(source, max_bytes=8 * 1024 * 1024)
        data = json.loads(raw.decode("utf-8-sig"))
        origin = source
    else:
        path = Path(bpy.path.abspath(source)).resolve()
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        origin = str(path)
    data = _validate_library(data)
    library = context.scene.scpaint_library
    library.name = data["name"]
    library.source = origin
    library.presets.clear()
    for entry in data["presets"]:
        item = library.presets.add()
        item.id = entry["id"]
        item.name = entry["name"]
        item.type = entry.get("type", "")
        item.mode = entry["mode"]
        item.invert_mask = entry.get("invert_mask", False)
        item.texture_scale = entry.get("texture_scale", 1.0)
        item.description = entry.get("description", "")
    return data


def _entry_by_id(context, preset_id):
    return next(
        (entry for entry in context.scene.scpaint_library.presets if entry.id == preset_id),
        None,
    )


def _preset_items(_self, context):
    presets = context.scene.scpaint_library.presets
    return [
        (preset.id, preset.name, preset.description, index)
        for index, preset in enumerate(presets)
    ] or [("NONE", "No presets", "Import or sync a Stalcraft v2 JSON library", 0)]


class SCPaintLibraryItem(PropertyGroup):
    id: StringProperty()
    name: StringProperty()
    type: StringProperty()
    mode: StringProperty()
    invert_mask: BoolProperty()
    texture_scale: FloatProperty()
    description: StringProperty()


class SCPaintLibrary(PropertyGroup):
    name: StringProperty(default="No library loaded")
    source: StringProperty()
    presets: CollectionProperty(type=SCPaintLibraryItem)


class SCPaintSceneSettings(PropertyGroup):
    preset: EnumProperty(name="Preset", items=_preset_items)


class SCPaintPreferences(AddonPreferences):
    bl_idname = ADDON_ID

    repository_url: StringProperty(
        name="Library URL",
        description="Raw JSON URL or a GitHub blob URL",
        default="",
    )

    def draw(self, _context):
        layout = self.layout
        layout.prop(self, "repository_url")
        layout.operator("scpaint.sync_repository", icon="URL")


class SCPAINT_OT_create_or_update(Operator):
    bl_idname = "scpaint.create_or_update"
    bl_label = "Create/Update Stalcraft paints"
    bl_description = "Create a Stalcraft paints node or rebuild the active one"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        space = getattr(context, "space_data", None)
        return (
            space is not None
            and space.type == "NODE_EDITOR"
            and getattr(space, "tree_type", "") == "ShaderNodeTree"
            and getattr(space, "edit_tree", None) is not None
        )

    def execute(self, context):
        tree = context.space_data.edit_tree
        node = _active_scpaint_node(context)
        if node is None:
            node = tree.nodes.new(NODE_IDNAME)
            node.location = context.space_data.cursor_location
            tree.nodes.active = node
            node.select = True
            self.report({"INFO"}, "Created Stalcraft paints node")
        else:
            node.rebuild_tree()
            self.report({"INFO"}, "Updated Stalcraft paints node")
        return {"FINISHED"}


class SCPAINT_OT_sync_repository(Operator):
    bl_idname = "scpaint.sync_repository"
    bl_label = "Sync Stalcraft Library"
    bl_description = "Download and validate the configured Git-hosted JSON library"

    def execute(self, context):
        preferences = context.preferences.addons[ADDON_ID].preferences
        if not preferences.repository_url.strip():
            self.report({"ERROR"}, "Set Library URL in add-on preferences")
            return {"CANCELLED"}
        try:
            data = _load_library(context, preferences.repository_url)
        except Exception as exc:
            self.report({"ERROR"}, f"Library sync failed: {exc}")
            return {"CANCELLED"}
        self.report(
            {"INFO"},
            f"Loaded {data.get('name', 'library')}: {len(data.get('presets', []))} presets",
        )
        return {"FINISHED"}


class SCPAINT_OT_import_library(Operator):
    bl_idname = "scpaint.import_library"
    bl_label = "Import Stalcraft Library"
    bl_description = "Load a local Stalcraft paints JSON library"

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.json", options={"HIDDEN"})

    def invoke(self, context, _event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        try:
            data = _load_library(context, self.filepath)
        except Exception as exc:
            self.report({"ERROR"}, f"Library import failed: {exc}")
            return {"CANCELLED"}
        self.report({"INFO"}, f"Loaded {len(data.get('presets', []))} presets")
        return {"FINISHED"}


class SCPAINT_OT_search_presets(Operator):
    bl_idname = "scpaint.search_presets"
    bl_label = "Search Stalcraft Presets"
    bl_description = "Show presets matching the active node search query"

    @classmethod
    def poll(cls, context):
        return _active_scpaint_node(context) is not None

    def execute(self, context):
        node = _active_scpaint_node(context)
        query = node.search_query.strip().casefold()
        presets = tuple(context.scene.scpaint_library.presets)
        matches = tuple(
            preset
            for preset in presets
            if not query
            or query in preset.id.casefold()
            or query in preset.name.casefold()
        )

        def draw_popup(menu, _popup_context):
            if not matches:
                menu.layout.label(text="No matching presets")
                return
            for preset in matches:
                operator = menu.layout.operator(
                    "scpaint.apply_preset",
                    text=preset.name,
                    icon_value=get_icon_value(),
                )
                operator.preset_id = preset.id

        context.window_manager.popup_menu(draw_popup, title="Stalcraft Presets")
        return {"FINISHED"}


class SCPAINT_OT_apply_preset(Operator):
    bl_idname = "scpaint.apply_preset"
    bl_label = "Apply Stalcraft Preset"
    bl_description = "Apply the selected JSON preset to the active Stalcraft node"
    bl_options = {"REGISTER", "UNDO"}

    preset_id: StringProperty(name="Preset ID")

    def execute(self, context):
        node = _active_scpaint_node(context)
        preset = _entry_by_id(context, self.preset_id)
        if node is None or preset is None:
            self.report({"ERROR"}, "Select a Stalcraft preset and active node")
            return {"CANCELLED"}
        try:
            node.mode = preset.mode
            node.invert_mask = preset.invert_mask
            node.texture_scale = preset.texture_scale
            node.category = preset.type.upper()
            node.manual_mode = False
            node.rebuild_tree()
        except Exception as exc:
            self.report({"ERROR"}, f"Preset failed: {exc}")
            return {"CANCELLED"}
        self.report({"INFO"}, f"Applied preset: {preset.name}")
        return {"FINISHED"}


class SCPAINT_PT_library(Panel):
    bl_label = "Stalcraft Paint Library"
    bl_space_type = "NODE_EDITOR"
    bl_region_type = "UI"
    bl_category = "Stalcraft"

    @classmethod
    def poll(cls, context):
        space = getattr(context, "space_data", None)
        return space and space.tree_type == "ShaderNodeTree"

    def draw(self, context):
        layout = self.layout
        # Reuse the Stalcraft preview in its sidebar instead of a built-in icon.
        layout.label(
            text=context.scene.scpaint_library.name or "No library loaded",
            icon_value=get_icon_value(),
        )
        row = layout.row(align=True)
        row.operator("scpaint.import_library", text="Import", icon="FILE_FOLDER")
        row.operator("scpaint.sync_repository", text="Sync Git", icon="URL")
        layout.operator("scpaint.create_or_update", icon_value=get_icon_value())

        settings = context.scene.scpaint_settings
        layout.prop(settings, "preset", text="Preset")
        operator = layout.operator("scpaint.apply_preset", text="Apply", icon="CHECKMARK")
        operator.preset_id = settings.preset


def _node_category_poll(context):
    space = getattr(context, "space_data", None)
    return space and space.tree_type == "ShaderNodeTree"


_NODE_CATEGORIES = None
_NODE_MENU_REGISTERED = False

# One named collection keeps icon ownership explicit and prevents duplicate previews.
_PREVIEW_COLLECTIONS = {}
_ICON_COLLECTION = "stalcraft_paints"
_ICON_NAME = "stalcraft"


def get_icon_value():
    """Return the shared Stalcraft preview id, or zero before icon registration."""
    previews = _PREVIEW_COLLECTIONS.get(_ICON_COLLECTION)
    if previews is not None and _ICON_NAME in previews:
        return previews[_ICON_NAME].icon_id
    return 0


def register_icons():
    """Load the add-on icon exactly once for all Stalcraft UI entry points."""
    if _ICON_COLLECTION in _PREVIEW_COLLECTIONS:
        return

    import bpy.utils.previews

    previews = bpy.utils.previews.new()
    icon_path = Path(__file__).with_name("icons") / "stalcraft.png"
    try:
        if icon_path.is_file():
            previews.load(_ICON_NAME, str(icon_path), "IMAGE")
        _PREVIEW_COLLECTIONS[_ICON_COLLECTION] = previews
    except Exception:
        # Do not leak Blender preview resources if loading the packaged PNG fails.
        bpy.utils.previews.remove(previews)
        raise


def unregister_icons():
    """Release the single preview collection owned by this add-on."""
    previews = _PREVIEW_COLLECTIONS.pop(_ICON_COLLECTION, None)
    if previews is None:
        return

    import bpy.utils.previews

    bpy.utils.previews.remove(previews)


def _draw_stalcraft_node_item(_item, layout, _context):
    # The node entry and its parent category intentionally share one preview id.
    props = layout.operator(
        "node.add_node", text="Stalcraft paints", icon_value=get_icon_value()
    )
    props.type = NODE_IDNAME
    props.use_transform = True


def _register_node_menu():
    global _NODE_CATEGORIES, _NODE_MENU_REGISTERED
    if _NODE_MENU_REGISTERED:
        return

    try:
        import nodeitems_utils

        class SCNodeCategory(nodeitems_utils.NodeCategory):
            @classmethod
            def poll(cls, context):
                return _node_category_poll(context)

        _NODE_CATEGORIES = [
            SCNodeCategory(
                "SC_PAINTS_STALCRAFT",
                "Stalcraft",
                items=[nodeitems_utils.NodeItemCustom(draw=_draw_stalcraft_node_item)],
            )
        ]
        nodeitems_utils.register_node_categories("SC_PAINTS_NODES", _NODE_CATEGORIES)
        # Draw only this generated category so its root row can receive icon_value.
        bpy.types.NODE_MT_shader_node_add_all.append(_draw_stalcraft_category)
    except (ImportError, AttributeError, KeyError):
        bpy.types.NODE_MT_shader_node_add_all.append(_draw_modern_node_menu)
    _NODE_MENU_REGISTERED = True


def _draw_stalcraft_category(self, context):
    if _node_category_poll(context):
        # nodeitems_utils creates this submenu but cannot set its root-row icon.
        self.layout.menu(
            "NODE_MT_category_SC_PAINTS_STALCRAFT",
            text="Stalcraft",
            icon_value=get_icon_value(),
        )


def _draw_modern_node_menu(self, context):
    if _node_category_poll(context):
        # Compatibility fallback still reuses the same preview collection.
        self.layout.operator(
            "node.add_node", text="Stalcraft paints", icon_value=get_icon_value()
        ).type = NODE_IDNAME


def _unregister_node_menu():
    global _NODE_CATEGORIES, _NODE_MENU_REGISTERED
    if not _NODE_MENU_REGISTERED:
        return

    # Remove either registered callback independently so partial registration is safe.
    for draw_callback in (_draw_stalcraft_category, _draw_modern_node_menu):
        try:
            bpy.types.NODE_MT_shader_node_add_all.remove(draw_callback)
        except (AttributeError, ValueError):
            pass

    try:
        import nodeitems_utils

        if _NODE_CATEGORIES is not None:
            nodeitems_utils.unregister_node_categories("SC_PAINTS_NODES")
    except (ImportError, AttributeError, KeyError):
        pass
    _NODE_CATEGORIES = None
    _NODE_MENU_REGISTERED = False


def _iter_shader_trees():
    seen = set()
    # Add-on registration can run under Blender's _RestrictData proxy, where
    # datablock collections are intentionally unavailable until registration ends.
    collections = tuple(
        getattr(bpy.data, name, ()) for name in ("materials", "worlds", "lights")
    )
    for collection in collections:
        for datablock in collection:
            tree = getattr(datablock, "node_tree", None)
            if tree is not None and tree.as_pointer() not in seen:
                seen.add(tree.as_pointer())
                yield tree
    for tree in getattr(bpy.data, "node_groups", ()):
        if tree.bl_idname == "ShaderNodeTree" and tree.as_pointer() not in seen:
            seen.add(tree.as_pointer())
            yield tree


def _msgbus_sync_node(node):
    # Msgbus only changes numeric selectors and texture mapping, never topology.
    try:
        if (
            node is not None
            and getattr(node, "node_tree", None) is not None
            and not node.get("_scpaint_rebuilding", False)
        ):
            node.sync_external_links()
    except (ReferenceError, RuntimeError):
        return


def _subscribe_existing_nodes():
    for tree in _iter_shader_trees():
        for node in tuple(tree.nodes):
            if getattr(node, "bl_idname", "") == NODE_IDNAME:
                node._subscribe_msgbus()


CLASSES = (
    SCPaintLibraryItem,
    SCPaintLibrary,
    SCShaderNodeStalcraftPaints,
    SCPaintSceneSettings,
    SCPaintPreferences,
    SCPAINT_OT_create_or_update,
    SCPAINT_OT_sync_repository,
    SCPAINT_OT_import_library,
    SCPAINT_OT_search_presets,
    SCPAINT_OT_apply_preset,
    SCPAINT_PT_library,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.scpaint_settings = PointerProperty(type=SCPaintSceneSettings)
    bpy.types.Scene.scpaint_library = PointerProperty(type=SCPaintLibrary)
    _subscribe_existing_nodes()
    # Menus and panels can safely request icon_value after this initialization.
    register_icons()
    _register_node_menu()


def unregister():
    for tree in _iter_shader_trees():
        for node in tuple(tree.nodes):
            if getattr(node, "bl_idname", "") == NODE_IDNAME:
                node._unsubscribe_msgbus()
    _unregister_node_menu()
    # Free previews only after every UI callback using their icon ids is removed.
    unregister_icons()
    if hasattr(bpy.types.Scene, "scpaint_settings"):
        del bpy.types.Scene.scpaint_settings
    if hasattr(bpy.types.Scene, "scpaint_library"):
        del bpy.types.Scene.scpaint_library
    for cls in reversed(CLASSES):
        if cls.is_registered:
            bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
